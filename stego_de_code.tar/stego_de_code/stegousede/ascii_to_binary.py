def char_to_binary(text):
    binary_string = ''
    for char in text:
        binary_char = format(ord(char), '08b')
        binary_string += binary_char
    return binary_string

input_text = "DE"
result = char_to_binary(input_text)
print(f"Binary string: {result}")