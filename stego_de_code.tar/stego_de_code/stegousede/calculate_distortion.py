import numpy as np
import sys

def read_matrix(file_path):
    matrix = []
    with open(file_path, 'r') as f:
        for line in f:
            row = list(map(int, line.strip().split()))
            matrix.append(row)
    return matrix

def calculate_distortion(original, stego):
    original = np.array(original)
    stego = np.array(stego)
    distortion = np.sum(np.abs(original - stego))
    return distortion

def main():
    original_file = sys.argv[1]
    stego_de_file = sys.argv[2]
    stego_dct_file = sys.argv[3]

    original = read_matrix(original_file)
    stego_de = read_matrix(stego_de_file)
    stego_dct = read_matrix(stego_dct_file)

    de_distortion = calculate_distortion(original, stego_de)
    dct_distortion = calculate_distortion(original, stego_dct)

    print(f"The distortion is:")
    print(f"- DE: {de_distortion}")
    print(f"- DCT: {dct_distortion}")

if __name__ == "__main__":
    main()
