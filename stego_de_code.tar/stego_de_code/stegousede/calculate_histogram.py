import numpy as np
import matplotlib.pyplot as plt
import sys

def read_matrix(file_path):
    matrix = []
    with open(file_path, 'r') as f:
        for line in f:
            row = list(map(int, line.strip().split()))
            matrix.append(row)
    return matrix

def calculate_histogram(matrix):
    flat = np.array(matrix).flatten()
    hist, _ = np.histogram(flat, bins=256, range=(0, 256))
    return hist

def histogram_difference(hist1, hist2):
    return np.sum(np.abs(hist1 - hist2))

def main():
    original_file = sys.argv[1]
    stego_de_file = sys.argv[2]
    stego_dct_file = sys.argv[3]

    original = read_matrix(original_file)
    stego_de = read_matrix(stego_de_file)
    stego_dct = read_matrix(stego_dct_file)

    hist_original = calculate_histogram(original)
    hist_de = calculate_histogram(stego_de)
    hist_dct = calculate_histogram(stego_dct)
    de_hist_diff = histogram_difference(hist_original, hist_de)
    dct_hist_diff = histogram_difference(hist_original, hist_dct)
    
    original_flat = np.array(original).flatten()
    de_flat = np.array(stego_de).flatten()
    dct_flat = np.array(stego_dct).flatten()

    plt.figure(figsize=(12, 6))
    plt.hist(original_flat, bins=64, range=(0, 256), alpha=0.5, label='Original', color='gray', edgecolor='black')
    plt.hist(de_flat, bins=64, range=(0, 256), alpha=0.5, label='DE', color='blue', edgecolor='black')
    plt.hist(dct_flat, bins=64, range=(0, 256), alpha=0.5, label='DCT', color='red', edgecolor='black')

    plt.title(f'Histogram Comparison: Original vs DE vs DCT\n'
              f'DE Difference: {de_hist_diff}, DCT Difference: {dct_hist_diff}', fontsize=14)
    plt.xlabel('Pixel Value (0-255)', fontsize=12)
    plt.ylabel('Frequency', fontsize=12)
    plt.legend(fontsize=12)
    plt.grid(True, alpha=0.3)

    plt.savefig('histogram_comparison.png')


    print(f"The difference histogram:")
    print(f"- DE: {de_hist_diff}")
    print(f"- DCT: {dct_hist_diff}")

if __name__ == "__main__":
    main()
