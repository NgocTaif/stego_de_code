from PIL import Image
import sys


def resize_image(input_path, output_path, size=(512, 512)):
    
    img_gray = Image.open(input_path).convert("L")
    
    img_resized = img_gray.resize(size)
    
    img_resized.save(output_path, format="PNG")
    
    print(f"Saved image: {output_path}")

input_image_path = sys.argv[1]
output_image_path = "img_gray_512x512.png"

resize_image(input_image_path, output_image_path)
