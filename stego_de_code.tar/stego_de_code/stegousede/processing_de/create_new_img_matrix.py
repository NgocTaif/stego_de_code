import numpy as np
import sys

def update_matrix_with_new_pairs(matrix_file, new_pairs_file, output_file):
    try:
        matrix = np.loadtxt(matrix_file, dtype=int)
    except Exception as e:
        raise ValueError(f"Can't read {matrix_file}. Error: {e}")

    new_pairs = []
    with open(new_pairs_file, 'r') as f:
        for line in f:
            x, y = map(int, line.strip().split())
            new_pairs.append((x, y))

    for i in range(8):
        matrix[0, 2*i] = new_pairs[i][0] 
        matrix[0, 2*i + 1] = new_pairs[i][1]  

    np.savetxt(output_file, matrix, fmt='%d')

    print(f"The new matrix: {output_file}")

matrix_file = sys.argv[1] 
new_pairs_file = sys.argv[2] 
output_file = "new_img_matrix.txt"
update_matrix_with_new_pairs(matrix_file, new_pairs_file, output_file)