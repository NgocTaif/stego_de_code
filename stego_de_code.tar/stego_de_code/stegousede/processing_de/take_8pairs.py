import numpy as np
import sys

def extract_pixel_pairs_from_txt(input_file, output_file):
    try:
        matrix = np.loadtxt(input_file, dtype=int)
    except Exception as e:
        raise ValueError(f"Can't read {input_file}. Error: {e}")

    first_row = matrix[0, :]

    pixel_pairs = [(first_row[i], first_row[i+1]) for i in range(0, 16, 2)]

    with open(output_file, 'w') as f:
        for pair in pixel_pairs:
            f.write(f"{pair[0]} {pair[1]}\n")

    print(f"Extracted 8 pairs: {output_file}")

input_file = sys.argv[1] 
output_file = "processing_de/8pairs.txt"
extract_pixel_pairs_from_txt(input_file, output_file)
